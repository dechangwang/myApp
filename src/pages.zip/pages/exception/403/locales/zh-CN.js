export default {
  'exceptionand403.exception.back': '返回首页',
  'exceptionand403.description.403': '抱歉，你无权访问该页面。',
};
