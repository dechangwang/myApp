export default {
  'exceptionand500.exception.back': '返回首页',
  'exceptionand500.description.500': '抱歉，服务器出错了。',
};
