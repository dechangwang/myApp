export default {
  'exceptionand500.exception.back': '返回首頁',
  'exceptionand500.description.500': '抱歉，服務器出錯了。',
};
