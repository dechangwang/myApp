export default {
  'exceptionand404.exception.back': 'Back to home',
  'exceptionand404.description.404': 'Sorry, the page you visited does not exist.',
};
