export default {
  'exceptionand404.exception.back': 'Voltar para Início',
  'exceptionand404.description.404': 'Desculpe, a página que você visitou não existe.',
};
