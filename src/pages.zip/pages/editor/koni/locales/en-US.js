export default {
  'editorandkoni.description':
    'The topology diagram refers to the network structure diagram composed of network node devices and communication media',
};
