export default {
  'editorandflow.description':
    'The flow chart is an excellent way to represent the idea of the algorithm',
};
